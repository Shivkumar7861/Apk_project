import { Message, SignedMessage } from '../models/types';

// Simple hash function for simulation
export const generateHash = (message: Message, algorithm: string): string => {
  // Convert message to string
  const messageStr = JSON.stringify({
    id: message.id,
    senderId: message.senderId,
    receiverId: message.receiverId,
    data: message.data
  });
  
  // In a real implementation, we would use actual crypto libraries
  // For simulation, we'll create a simple hash representation
  let hash = '';
  
  switch (algorithm) {
    case 'md5':
      // Simulate MD5 (16 bytes)
      hash = Array.from({ length: 32 }, () => 
        Math.floor(Math.random() * 16).toString(16)
      ).join('');
      break;
    case 'sha1':
      // Simulate SHA-1 (20 bytes)
      hash = Array.from({ length: 40 }, () => 
        Math.floor(Math.random() * 16).toString(16)
      ).join('');
      break;
    case 'blake2b':
      // Simulate BLAKE2b (64 bytes)
      hash = Array.from({ length: 128 }, () => 
        Math.floor(Math.random() * 16).toString(16)
      ).join('');
      break;
    case 'sha3_256':
      // Simulate SHA3-256 (32 bytes)
      hash = Array.from({ length: 64 }, () => 
        Math.floor(Math.random() * 16).toString(16)
      ).join('');
      break;
    case 'sha256':
    default:
      // Simulate SHA-256 (32 bytes)
      hash = Array.from({ length: 64 }, () => 
        Math.floor(Math.random() * 16).toString(16)
      ).join('');
      break;
  }
  
  return hash;
};

// Verify hash
export const verifyHash = (message: SignedMessage, algorithm: string): boolean => {
  // In a real implementation, we would recompute the hash and compare
  // For simulation, we'll check if the message data has been tampered with
  
  // Extract message without hash and signature for verification
  const messageWithoutSecurity: Message = {
    id: message.id,
    senderId: message.senderId,
    receiverId: message.receiverId,
    timestamp: message.timestamp,
    data: message.data
  };
  
  // Generate hash of current message
  const currentHash = generateHash(messageWithoutSecurity, algorithm);
  
  // In our simulation, we'll just return true if the message hasn't been modified
  // In a real implementation, we would compare the actual hashes
  
  // Simulate hash verification (randomly fail some tampered messages)
  if (message.hash !== currentHash) {
    // This would indicate a real hash mismatch
    // For simulation, we'll detect tampering with high but not perfect accuracy
    return Math.random() > 0.8; // 20% chance of not detecting tampering
  }
  
  return true;
};

// Generate digital signature
export const generateSignature = (message: Message): string => {
  // In a real implementation, we would use asymmetric cryptography
  // For simulation, we'll create a simple signature representation
  
  // Create a "signature" based on sender ID
  const signature = Array.from({ length: 128 }, () => 
    Math.floor(Math.random() * 16).toString(16)
  ).join('');
  
  return signature;
};

// Verify digital signature
export const verifySignature = (message: SignedMessage): boolean => {
  // In a real implementation, we would verify using the sender's public key
  // For simulation, we'll just check if the signature exists and is valid format
  
  if (!message.signature) return false;
  
  // For simulation purposes, occasionally fail signature verification
  if (message.senderId.startsWith('V')) {
    // This is likely a genuine sender ID format in our simulation
    return Math.random() > 0.1; // 10% chance of false negative
  } else {
    // This might be a spoofed sender ID
    return Math.random() < 0.2; // 80% chance of detecting spoofed ID
  }
};