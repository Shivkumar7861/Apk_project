import { Vehicle } from './types';

// Generate random vehicles for simulation
export const generateVehicles = (count: number): Vehicle[] => {
  const vehicles: Vehicle[] = [];
  
  for (let i = 0; i < count; i++) {
    vehicles.push({
      id: `V${i + 1}`,
      speed: Math.random() * 5 + 2, // Speed between 2-7
      position: [
        Math.random() * 90 + 5, // x between 5-95
        Math.random() * 90 + 5  // y between 5-95
      ],
      direction: Math.random() * Math.PI * 2, // Random direction
      salt: `vanet-${Math.random().toString(36).substring(2, 15)}`
    });
  }
  
  return vehicles;
};

// Calculate distance between two vehicles
export const calculateDistance = (v1: Vehicle, v2: Vehicle): number => {
  const dx = v1.position[0] - v2.position[0];
  const dy = v1.position[1] - v2.position[1];
  return Math.sqrt(dx * dx + dy * dy);
};

// Check if two vehicles are in communication range
export const isInRange = (v1: Vehicle, v2: Vehicle, range: number = 30): boolean => {
  return calculateDistance(v1, v2) <= range;
};