// Basic vehicle type
export interface Vehicle {
  id: string;
  speed: number;
  position: [number, number]; // [x, y]
  direction: number;
  salt: string;
}

// Basic message type
export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  timestamp: number;
  data: {
    position: [number, number];
    speed: number;
    direction: number;
  };
}

// Message with security features
export interface SignedMessage extends Message {
  hash: string;
  signature: string | null;
}

// Route for visualization
export interface Route {
  from: string;
  to: string;
  secure: boolean;
}