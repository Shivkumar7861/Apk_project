import React, { useState } from 'react';
import SimulationContainer from './components/SimulationContainer';
import ControlPanel from './components/ControlPanel';
import MetricsPanel from './components/MetricsPanel';
import { SimulationProvider } from './context/SimulationContext';
import { SecurityProvider } from './context/SecurityContext';
import { NetworkProvider } from './context/NetworkContext';
import Header from './components/Header';

function App() {
  const [isRunning, setIsRunning] = useState(false);
  const [simulationSpeed, setSimulationSpeed] = useState(1);

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
      <SecurityProvider>
        <NetworkProvider>
          <SimulationProvider>
            <Header />
            <div className="flex flex-col md:flex-row flex-1 p-4 gap-4">
              <div className="w-full md:w-3/4 bg-gray-800 rounded-lg shadow-lg overflow-hidden">
                <SimulationContainer isRunning={isRunning} speed={simulationSpeed} />
              </div>
              <div className="w-full md:w-1/4 flex flex-col gap-4">
                <ControlPanel 
                  isRunning={isRunning} 
                  onToggleRunning={() => setIsRunning(!isRunning)}
                  simulationSpeed={simulationSpeed}
                  onSpeedChange={setSimulationSpeed}
                />
                <MetricsPanel />
              </div>
            </div>
          </SimulationProvider>
        </NetworkProvider>
      </SecurityProvider>
    </div>
  );
}

export default App;