import React, { useState } from 'react';
import { Play, Pause, Plus, Minus, RefreshCw, Shield, AlertTriangle } from 'lucide-react';
import { useSimulation } from '../context/SimulationContext';
import { useSecurity } from '../context/SecurityContext';

interface ControlPanelProps {
  isRunning: boolean;
  onToggleRunning: () => void;
  simulationSpeed: number;
  onSpeedChange: (speed: number) => void;
}

const ControlPanel: React.FC<ControlPanelProps> = ({ 
  isRunning, 
  onToggleRunning,
  simulationSpeed,
  onSpeedChange
}) => {
  const { resetVehicles, vehicleCount, setVehicleCount } = useSimulation();
  const { hashAlgorithm, setHashAlgorithm, useDigitalSignature, setUseDigitalSignature } = useSecurity();
  const [attackProbability, setAttackProbability] = useState(0);

  const handleSpeedChange = (increment: boolean) => {
    const newSpeed = increment 
      ? Math.min(simulationSpeed + 0.5, 3) 
      : Math.max(simulationSpeed - 0.5, 0.5);
    onSpeedChange(newSpeed);
  };

  const handleVehicleCountChange = (increment: boolean) => {
    const newCount = increment 
      ? Math.min(vehicleCount + 1, 10) 
      : Math.max(vehicleCount - 1, 2);
    setVehicleCount(newCount);
  };

  const handleReset = () => {
    if (isRunning) onToggleRunning();
    resetVehicles();
  };

  const handleAttackProbabilityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAttackProbability(Number(e.target.value));
  };

  return (
    <div className="bg-gray-800 rounded-lg shadow-lg p-4 flex flex-col gap-4">
      <div>
        <h2 className="text-lg font-medium mb-4">Simulation Controls</h2>
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <span>Simulation</span>
            <button 
              onClick={onToggleRunning}
              className={`p-2 rounded-full ${isRunning ? 'bg-red-500' : 'bg-green-500'} text-white`}
            >
              {isRunning ? <Pause size={16} /> : <Play size={16} />}
            </button>
          </div>
          
          <div className="flex items-center justify-between">
            <span>Speed: {simulationSpeed.toFixed(1)}x</span>
            <div className="flex gap-2">
              <button 
                onClick={() => handleSpeedChange(false)}
                disabled={simulationSpeed <= 0.5}
                className="p-1 bg-gray-700 rounded text-white disabled:opacity-50"
              >
                <Minus size={16} />
              </button>
              <button 
                onClick={() => handleSpeedChange(true)}
                disabled={simulationSpeed >= 3}
                className="p-1 bg-gray-700 rounded text-white disabled:opacity-50"
              >
                <Plus size={16} />
              </button>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <span>Vehicles: {vehicleCount}</span>
            <div className="flex gap-2">
              <button 
                onClick={() => handleVehicleCountChange(false)}
                disabled={vehicleCount <= 2}
                className="p-1 bg-gray-700 rounded text-white disabled:opacity-50"
              >
                <Minus size={16} />
              </button>
              <button 
                onClick={() => handleVehicleCountChange(true)}
                disabled={vehicleCount >= 10}
                className="p-1 bg-gray-700 rounded text-white disabled:opacity-50"
              >
                <Plus size={16} />
              </button>
            </div>
          </div>
          
          <button 
            onClick={handleReset}
            className="flex items-center justify-center gap-2 p-2 bg-gray-700 rounded text-white"
          >
            <RefreshCw size={16} />
            <span>Reset Simulation</span>
          </button>
        </div>
      </div>
      
      <div className="border-t border-gray-700 pt-4">
        <h2 className="text-lg font-medium mb-4">Security Settings</h2>
        <div className="flex flex-col gap-4">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Hash Algorithm</label>
            <select 
              value={hashAlgorithm}
              onChange={(e) => setHashAlgorithm(e.target.value)}
              className="w-full bg-gray-700 text-white p-2 rounded"
            >
              <option value="sha256">SHA-256</option>
              <option value="md5">MD5</option>
              <option value="sha1">SHA-1</option>
              <option value="blake2b">BLAKE2b</option>
              <option value="sha3_256">SHA3-256</option>
            </select>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1">
              <Shield size={16} className="text-blue-500" />
              <span>Digital Signatures</span>
            </span>
            <div className="relative inline-block w-10 align-middle">
              <input 
                type="checkbox" 
                id="toggle"
                className="sr-only"
                checked={useDigitalSignature}
                onChange={() => setUseDigitalSignature(!useDigitalSignature)}
              />
              <label 
                htmlFor="toggle" 
                className={`block h-6 w-10 rounded-full ${useDigitalSignature ? 'bg-blue-500' : 'bg-gray-700'} transition-colors duration-200 cursor-pointer`}
              >
                <span 
                  className={`block h-4 w-4 mt-1 ml-1 rounded-full bg-white transition-transform duration-200 transform ${useDigitalSignature ? 'translate-x-4' : ''}`}
                />
              </label>
            </div>
          </div>
          
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-sm text-gray-400 flex items-center gap-1">
                <AlertTriangle size={16} className="text-yellow-500" />
                <span>Attack Simulation: {attackProbability}%</span>
              </label>
            </div>
            <input 
              type="range"
              min="0"
              max="100"
              value={attackProbability}
              onChange={handleAttackProbabilityChange}
              className="w-full"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ControlPanel;