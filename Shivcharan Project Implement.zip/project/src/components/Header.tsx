import React from 'react';
import { Shield } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gray-800 border-b border-gray-700 p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Shield className="text-blue-500" size={24} />
          <h1 className="text-xl font-bold">VANET Secure Routing Protocol</h1>
        </div>
        <div className="text-sm text-gray-400">Simulation Environment</div>
      </div>
    </header>
  );
};

export default Header;