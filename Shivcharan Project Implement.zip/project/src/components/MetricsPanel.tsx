import React, { useState, useEffect } from 'react';
import { BarChart, RefreshCw, Check, X, Shield } from 'lucide-react';
import { useSecurity } from '../context/SecurityContext';
import { useSimulation } from '../context/SimulationContext';

const MetricsPanel: React.FC = () => {
  const { attacksDetected, attacksAttempted, hashStats } = useSecurity();
  const { messagesDelivered, messagesTotal } = useSimulation();
  
  const [activeTab, setActiveTab] = useState('metrics');
  const [deliveryRatio, setDeliveryRatio] = useState(0);
  const [securityRatio, setSecurityRatio] = useState(0);
  
  useEffect(() => {
    if (messagesTotal > 0) {
      setDeliveryRatio((messagesDelivered / messagesTotal) * 100);
    }
    
    if (attacksAttempted > 0) {
      setSecurityRatio((attacksDetected / attacksAttempted) * 100);
    }
  }, [messagesDelivered, messagesTotal, attacksDetected, attacksAttempted]);

  return (
    <div className="bg-gray-800 rounded-lg shadow-lg flex flex-col flex-1">
      <div className="flex border-b border-gray-700">
        <button 
          className={`px-4 py-2 ${activeTab === 'metrics' ? 'bg-gray-700 text-white' : 'text-gray-400'} font-medium`}
          onClick={() => setActiveTab('metrics')}
        >
          <div className="flex items-center gap-1">
            <BarChart size={16} />
            <span>Metrics</span>
          </div>
        </button>
        <button 
          className={`px-4 py-2 ${activeTab === 'security' ? 'bg-gray-700 text-white' : 'text-gray-400'} font-medium`}
          onClick={() => setActiveTab('security')}
        >
          <div className="flex items-center gap-1">
            <Shield size={16} />
            <span>Security</span>
          </div>
        </button>
      </div>
      
      <div className="p-4 flex-1 overflow-auto">
        {activeTab === 'metrics' ? (
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-gray-400">Packet Delivery Ratio</span>
                <span className="text-sm font-medium">{deliveryRatio.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full" 
                  style={{ width: `${deliveryRatio}%` }}
                />
              </div>
            </div>
            
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-gray-400">End-to-End Delay</span>
                <span className="text-sm font-medium">68ms</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-yellow-500 h-2 rounded-full" 
                  style={{ width: '68%' }}
                />
              </div>
            </div>
            
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-gray-400">Throughput</span>
                <span className="text-sm font-medium">87.4 kb/s</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-green-500 h-2 rounded-full" 
                  style={{ width: '87.4%' }}
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-2 mt-4">
              <div className="bg-gray-700 p-3 rounded">
                <div className="text-2xl font-bold">{messagesDelivered}</div>
                <div className="text-xs text-gray-400">Messages Delivered</div>
              </div>
              <div className="bg-gray-700 p-3 rounded">
                <div className="text-2xl font-bold">{messagesTotal}</div>
                <div className="text-xs text-gray-400">Total Messages</div>
              </div>
              <div className="bg-gray-700 p-3 rounded">
                <div className="text-2xl font-bold text-green-500">{attacksDetected}</div>
                <div className="text-xs text-gray-400">Attacks Detected</div>
              </div>
              <div className="bg-gray-700 p-3 rounded">
                <div className="text-2xl font-bold text-red-500">{attacksAttempted - attacksDetected}</div>
                <div className="text-xs text-gray-400">Attacks Missed</div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-gray-400">Attack Detection Rate</span>
                <span className="text-sm font-medium">{securityRatio.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full ${securityRatio > 70 ? 'bg-green-500' : 'bg-red-500'}`}
                  style={{ width: `${securityRatio}%` }}
                />
              </div>
            </div>
            
            <div className="bg-gray-700 p-3 rounded">
              <h3 className="text-sm font-medium mb-2">Hash Algorithm Performance</h3>
              <div className="space-y-2 text-xs">
                {Object.entries(hashStats).map(([name, time]) => (
                  <div key={name} className="flex justify-between">
                    <span>{name}</span>
                    <span>{time.toFixed(3)}ms</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-gray-700 p-3 rounded">
              <h3 className="text-sm font-medium mb-2">Security Status</h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs">Message Integrity</span>
                  <span className="flex items-center text-green-500">
                    <Check size={16} />
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs">Authentication</span>
                  <span className="flex items-center text-green-500">
                    <Check size={16} />
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs">Non-repudiation</span>
                  <span className="flex items-center text-yellow-500">
                    <RefreshCw size={16} />
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs">Sybil Attack Protection</span>
                  <span className="flex items-center text-red-500">
                    <X size={16} />
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MetricsPanel;