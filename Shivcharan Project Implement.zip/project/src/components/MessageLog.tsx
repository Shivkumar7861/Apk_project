import React from 'react';

interface MessageLogProps {
  logs: string[];
}

const MessageLog: React.FC<MessageLogProps> = ({ logs }) => {
  return (
    <div className="w-1/3 border-l border-gray-700 overflow-auto">
      <div className="p-2 bg-gray-700 text-sm font-medium">Message Log</div>
      <div className="p-2 h-full overflow-auto">
        {logs.length === 0 ? (
          <div className="text-gray-500 text-center py-4">
            No messages yet. Start the simulation to see message exchanges.
          </div>
        ) : (
          <div className="space-y-1">
            {logs.map((log, index) => (
              <div 
                key={index} 
                className="text-xs font-mono p-1 border-l-2 border-blue-500 bg-gray-800"
              >
                {log}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default MessageLog;