import React, { useRef, useEffect, useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { useNetwork } from '../context/NetworkContext';
import MessageLog from './MessageLog';

interface SimulationContainerProps {
  isRunning: boolean;
  speed: number;
}

const SimulationContainer: React.FC<SimulationContainerProps> = ({ isRunning, speed }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const { vehicles, updateVehicles, sendMessages } = useSimulation();
  const { routes } = useNetwork();
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
  const [logs, setLogs] = useState<string[]>([]);

  // Handle resize
  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.clientWidth,
          height: containerRef.current.clientHeight - 40 // Subtract for tabs/controls
        });
      }
    };

    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  // Animation loop
  useEffect(() => {
    if (!isRunning) return;
    
    let animationId: number;
    const dt = 0.1 * speed;
    
    const animate = () => {
      updateVehicles(dt);
      
      // Generate and send messages periodically
      if (Math.random() < 0.1) {
        const newLogs = sendMessages();
        if (newLogs.length) {
          setLogs(prev => [...newLogs, ...prev].slice(0, 50));
        }
      }
      
      animationId = requestAnimationFrame(animate);
    };
    
    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, [isRunning, speed, updateVehicles, sendMessages]);

  // Render simulation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const { width, height } = dimensions;
    
    // Clear canvas
    ctx.clearRect(0, 0, width, height);
    
    // Draw roads/map (simple grid)
    ctx.strokeStyle = '#444';
    ctx.lineWidth = 1;
    
    // Horizontal roads
    for (let y = 50; y < height; y += 100) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
    
    // Vertical roads
    for (let x = 50; x < width; x += 100) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    
    // Draw routes
    routes.forEach(route => {
      const { from, to, secure } = route;
      const fromVehicle = vehicles.find(v => v.id === from);
      const toVehicle = vehicles.find(v => v.id === to);
      
      if (fromVehicle && toVehicle) {
        ctx.beginPath();
        ctx.moveTo(fromVehicle.position[0] * width / 100, fromVehicle.position[1] * height / 100);
        ctx.lineTo(toVehicle.position[0] * width / 100, toVehicle.position[1] * height / 100);
        ctx.strokeStyle = secure ? '#10B981' : '#EF4444';
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    });
    
    // Draw vehicles
    vehicles.forEach(vehicle => {
      const x = vehicle.position[0] * width / 100;
      const y = vehicle.position[1] * height / 100;
      
      // Vehicle body
      ctx.beginPath();
      ctx.arc(x, y, 10, 0, Math.PI * 2);
      ctx.fillStyle = '#3B82F6';
      ctx.fill();
      
      // Vehicle ID
      ctx.fillStyle = '#fff';
      ctx.font = '10px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(vehicle.id, x, y);
    });
    
  }, [vehicles, routes, dimensions]);

  return (
    <div className="flex flex-col h-full" ref={containerRef}>
      <div className="flex border-b border-gray-700">
        <button className="px-4 py-2 bg-gray-700 text-white font-medium">Simulation</button>
        <button className="px-4 py-2 text-gray-400">Network Map</button>
      </div>
      <div className="flex flex-1">
        <div className="relative flex-1">
          <canvas 
            ref={canvasRef} 
            width={dimensions.width} 
            height={dimensions.height}
            className="absolute inset-0"
          />
        </div>
        <MessageLog logs={logs} />
      </div>
    </div>
  );
};

export default SimulationContainer;