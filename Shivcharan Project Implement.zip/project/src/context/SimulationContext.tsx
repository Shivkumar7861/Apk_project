import React, { createContext, useContext, useState, useCallback } from 'react';
import { useSecurity } from './SecurityContext';
import { useNetwork } from './NetworkContext';
import { Vehicle, Message } from '../models/types';
import { generateVehicles } from '../models/Vehicle';

interface SimulationContextType {
  vehicles: Vehicle[];
  vehicleCount: number;
  setVehicleCount: (count: number) => void;
  updateVehicles: (dt: number) => void;
  resetVehicles: () => void;
  sendMessages: () => string[];
  messagesDelivered: number;
  messagesTotal: number;
}

const SimulationContext = createContext<SimulationContextType | undefined>(undefined);

export const SimulationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [vehicles, setVehicles] = useState<Vehicle[]>(generateVehicles(5));
  const [vehicleCount, setVehicleCount] = useState(5);
  const [messagesDelivered, setMessagesDelivered] = useState(0);
  const [messagesTotal, setMessagesTotal] = useState(0);
  
  const { verifyMessageIntegrity, signMessage, attacksDetected, setAttacksDetected, attacksAttempted, setAttacksAttempted } = useSecurity();
  const { addRoute, clearRoutes } = useNetwork();

  // Reset simulation
  const resetVehicles = useCallback(() => {
    setVehicles(generateVehicles(vehicleCount));
    setMessagesDelivered(0);
    setMessagesTotal(0);
    clearRoutes();
  }, [vehicleCount, clearRoutes]);

  // Update vehicle count
  const handleSetVehicleCount = useCallback((count: number) => {
    setVehicleCount(count);
    setVehicles(generateVehicles(count));
    clearRoutes();
  }, [clearRoutes]);

  // Update vehicle positions
  const updateVehicles = useCallback((dt: number) => {
    setVehicles(prevVehicles => {
      return prevVehicles.map(vehicle => {
        // Simple movement with bounds checking
        const newX = Math.max(0, Math.min(100, vehicle.position[0] + vehicle.speed * dt * Math.cos(vehicle.direction)));
        const newY = Math.max(0, Math.min(100, vehicle.position[1] + vehicle.speed * dt * Math.sin(vehicle.direction)));
        
        // Change direction if hitting boundary
        let newDirection = vehicle.direction;
        if (newX <= 0 || newX >= 100) {
          newDirection = Math.PI - newDirection;
        }
        if (newY <= 0 || newY >= 100) {
          newDirection = -newDirection;
        }
        
        // Small random direction changes
        newDirection += (Math.random() - 0.5) * 0.2;
        
        return {
          ...vehicle,
          position: [newX, newY],
          direction: newDirection
        };
      });
    });
  }, []);

  // Send messages between vehicles
  const sendMessages = useCallback(() => {
    const logs: string[] = [];
    
    if (vehicles.length < 2) return logs;
    
    // Pick random sender
    const senderIndex = Math.floor(Math.random() * vehicles.length);
    const sender = vehicles[senderIndex];
    
    // Find vehicles in range (simplified)
    const inRangeVehicles = vehicles.filter((v, idx) => {
      if (idx === senderIndex) return false;
      
      const dx = v.position[0] - sender.position[0];
      const dy = v.position[1] - sender.position[1];
      const distance = Math.sqrt(dx * dx + dy * dy);
      
      return distance < 30; // Communication range
    });
    
    if (inRangeVehicles.length === 0) return logs;
    
    // Send message to a random vehicle in range
    const receiver = inRangeVehicles[Math.floor(Math.random() * inRangeVehicles.length)];
    
    // Create message
    const message: Message = {
      id: `msg-${Date.now()}`,
      senderId: sender.id,
      receiverId: receiver.id,
      timestamp: Date.now(),
      data: {
        position: sender.position,
        speed: sender.speed,
        direction: sender.direction
      }
    };
    
    // Sign message
    const signedMessage = signMessage(message);
    
    // Simulate attack (randomly alter message)
    const shouldAttack = Math.random() < 0.2;
    let attackType = '';
    
    if (shouldAttack) {
      setAttacksAttempted(prev => prev + 1);
      
      // Types of attacks
      const attackTypes = ['position', 'speed', 'sender'];
      attackType = attackTypes[Math.floor(Math.random() * attackTypes.length)];
      
      if (attackType === 'position') {
        signedMessage.data.position = [
          signedMessage.data.position[0] + (Math.random() * 20 - 10),
          signedMessage.data.position[1] + (Math.random() * 20 - 10)
        ];
        logs.push(`🚨 Attack: Vehicle ${sender.id} position data tampered`);
      } else if (attackType === 'speed') {
        signedMessage.data.speed = signedMessage.data.speed * (1 + Math.random());
        logs.push(`🚨 Attack: Vehicle ${sender.id} speed data tampered`);
      } else if (attackType === 'sender') {
        const fakeSenderId = `V${Math.floor(Math.random() * 100)}`;
        signedMessage.senderId = fakeSenderId;
        logs.push(`🚨 Attack: Impersonation attack - fake sender ${fakeSenderId}`);
      }
    }
    
    // Verify message at receiver
    const isValid = verifyMessageIntegrity(signedMessage);
    
    if (shouldAttack && isValid === false) {
      setAttacksDetected(prev => prev + 1);
      logs.push(`✅ Attack detected: Message from ${signedMessage.senderId} to ${receiver.id} rejected`);
    } else if (shouldAttack) {
      logs.push(`❌ Attack successful: Tampered message accepted by ${receiver.id}`);
    } else {
      logs.push(`📨 Secure message from ${sender.id} to ${receiver.id} delivered`);
      setMessagesDelivered(prev => prev + 1);
    }
    
    setMessagesTotal(prev => prev + 1);
    
    // Add route for visualization
    addRoute({
      from: sender.id,
      to: receiver.id,
      secure: !shouldAttack || (shouldAttack && isValid === false)
    });
    
    return logs;
  }, [vehicles, signMessage, verifyMessageIntegrity, setAttacksDetected, setAttacksAttempted, addRoute]);

  return (
    <SimulationContext.Provider value={{
      vehicles,
      vehicleCount,
      setVehicleCount: handleSetVehicleCount,
      updateVehicles,
      resetVehicles,
      sendMessages,
      messagesDelivered,
      messagesTotal
    }}>
      {children}
    </SimulationContext.Provider>
  );
};

export const useSimulation = () => {
  const context = useContext(SimulationContext);
  if (context === undefined) {
    throw new Error('useSimulation must be used within a SimulationProvider');
  }
  return context;
};