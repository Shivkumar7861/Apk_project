import React, { createContext, useContext, useState, useCallback } from 'react';
import { Message, SignedMessage } from '../models/types';
import { generateHash, verifyHash, generateSignature, verifySignature } from '../utils/cryptography';

interface SecurityContextType {
  hashAlgorithm: string;
  setHashAlgorithm: (algorithm: string) => void;
  useDigitalSignature: boolean;
  setUseDigitalSignature: (use: boolean) => void;
  signMessage: (message: Message) => SignedMessage;
  verifyMessageIntegrity: (message: SignedMessage) => boolean;
  attacksDetected: number;
  setAttacksDetected: (count: number) => void;
  attacksAttempted: number;
  setAttacksAttempted: (count: number) => void;
  hashStats: Record<string, number>;
}

const SecurityContext = createContext<SecurityContextType | undefined>(undefined);

export const SecurityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [hashAlgorithm, setHashAlgorithm] = useState('sha256');
  const [useDigitalSignature, setUseDigitalSignature] = useState(true);
  const [attacksDetected, setAttacksDetected] = useState(0);
  const [attacksAttempted, setAttacksAttempted] = useState(0);
  const [hashStats, setHashStats] = useState<Record<string, number>>({
    'sha256': 0.58,
    'md5': 0.23,
    'sha1': 0.31,
    'blake2b': 0.76,
    'sha3_256': 0.69
  });

  // Sign a message using selected algorithm
  const signMessage = useCallback((message: Message): SignedMessage => {
    const startTime = performance.now();
    
    // Generate hash
    const hash = generateHash(message, hashAlgorithm);
    
    // Generate signature if enabled
    let signature = null;
    if (useDigitalSignature) {
      signature = generateSignature(message);
    }
    
    const endTime = performance.now();
    
    // Update hash stats
    setHashStats(prev => ({
      ...prev,
      [hashAlgorithm]: (prev[hashAlgorithm] * 9 + (endTime - startTime)) / 10 // Moving average
    }));
    
    return {
      ...message,
      hash,
      signature
    };
  }, [hashAlgorithm, useDigitalSignature]);

  // Verify message integrity
  const verifyMessageIntegrity = useCallback((message: SignedMessage): boolean => {
    // First verify hash
    const isHashValid = verifyHash(message, hashAlgorithm);
    
    // Then verify signature if enabled
    let isSignatureValid = true;
    if (useDigitalSignature && message.signature) {
      isSignatureValid = verifySignature(message);
    }
    
    return isHashValid && isSignatureValid;
  }, [hashAlgorithm, useDigitalSignature]);

  return (
    <SecurityContext.Provider value={{
      hashAlgorithm,
      setHashAlgorithm,
      useDigitalSignature,
      setUseDigitalSignature,
      signMessage,
      verifyMessageIntegrity,
      attacksDetected,
      setAttacksDetected,
      attacksAttempted,
      setAttacksAttempted,
      hashStats
    }}>
      {children}
    </SecurityContext.Provider>
  );
};

export const useSecurity = () => {
  const context = useContext(SecurityContext);
  if (context === undefined) {
    throw new Error('useSecurity must be used within a SecurityProvider');
  }
  return context;
};