import React, { createContext, useContext, useState, useCallback } from 'react';
import { Route } from '../models/types';

interface NetworkContextType {
  routes: Route[];
  addRoute: (route: Route) => void;
  removeRoute: (fromId: string, toId: string) => void;
  clearRoutes: () => void;
}

const NetworkContext = createContext<NetworkContextType | undefined>(undefined);

export const NetworkProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [routes, setRoutes] = useState<Route[]>([]);
  
  // Add a new route
  const addRoute = useCallback((route: Route) => {
    setRoutes(prev => {
      // Keep only the most recent 10 routes for visualization clarity
      const newRoutes = [...prev, route];
      if (newRoutes.length > 10) {
        return newRoutes.slice(newRoutes.length - 10);
      }
      return newRoutes;
    });
  }, []);
  
  // Remove a route
  const removeRoute = useCallback((fromId: string, toId: string) => {
    setRoutes(prev => 
      prev.filter(route => !(route.from === fromId && route.to === toId))
    );
  }, []);
  
  // Clear all routes
  const clearRoutes = useCallback(() => {
    setRoutes([]);
  }, []);

  return (
    <NetworkContext.Provider value={{
      routes,
      addRoute,
      removeRoute,
      clearRoutes
    }}>
      {children}
    </NetworkContext.Provider>
  );
};

export const useNetwork = () => {
  const context = useContext(NetworkContext);
  if (context === undefined) {
    throw new Error('useNetwork must be used within a NetworkProvider');
  }
  return context;
};